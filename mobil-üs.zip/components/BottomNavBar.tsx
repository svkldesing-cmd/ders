import React from 'react';
import { ScreenType } from '../types';

interface BottomNavBarProps {
  currentScreen: ScreenType;
  onNavigate: (screen: ScreenType) => void;
}

const BottomNavBar: React.FC<BottomNavBarProps> = ({ currentScreen, onNavigate }) => {
  const navItems = [
    { key: 'smart_feed', icon: 'dashboard', label: 'Akış' },
    { key: 'courses', icon: 'school', label: 'Dersler' },
    { key: 'library', icon: 'local_library', label: 'Kütüphane' },
    { key: 'statistics', icon: 'bar_chart', label: 'İstatistik' },
    // { key: 'profile', icon: 'person', label: 'Profil' }, // Profile is not fully implemented in separate screen for this exercise.
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto z-50 bg-background-dark/95 backdrop-blur-lg pb-6 pt-3 px-6 rounded-t-3xl border-t border-white/5 shadow-[0_-5px_20px_rgba(0,0,0,0.1)]">
      <div className="flex items-center justify-between">
        {navItems.map((item) => (
          <button
            key={item.key}
            onClick={() => onNavigate(item.key as ScreenType)}
            className="flex flex-col items-center gap-1 flex-1 group"
          >
            <div
              className={`p-1.5 rounded-xl transition-colors ${
                currentScreen === item.key
                  ? 'bg-primary/10 text-primary'
                  : 'text-text-secondary group-hover:text-white group-hover:bg-white/5'
              }`}
            >
              <span
                className={`material-symbols-outlined ${
                  currentScreen === item.key ? 'fill-1' : ''
                } ${item.key === 'smart_feed' && currentScreen === item.key ? 'relative' : ''}`}
              >
                {item.icon}
                {item.key === 'smart_feed' && currentScreen === item.key && (
                    <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-primary shadow-sm"></span>
                )}
              </span>
            </div>
            <span
              className={`text-[10px] ${
                currentScreen === item.key ? 'font-bold text-white' : 'font-medium text-text-secondary group-hover:text-white'
              }`}
            >
              {item.label}
            </span>
          </button>
        ))}
      </div>
      <div className="h-1 w-1/3 bg-white/20 mx-auto mt-4 rounded-full"></div>
    </nav>
  );
};

export default BottomNavBar;