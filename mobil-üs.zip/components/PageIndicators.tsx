import React from 'react';

interface PageIndicatorsProps {
  totalSteps: number;
  currentStep: number;
}

const PageIndicators: React.FC<PageIndicatorsProps> = ({ totalSteps, currentStep }) => {
  return (
    <div className="flex w-full flex-row items-center justify-center gap-2 py-3 px-6 z-10">
      {Array.from({ length: totalSteps }).map((_, index) => (
        <div
          key={index}
          className={`h-1.5 flex-1 rounded-full ${
            index === currentStep - 1
              ? 'bg-primary shadow-[0_0_12px_rgba(19,127,236,0.6)]'
              : 'bg-slate-200 dark:bg-slate-700/50'
          }`}
        ></div>
      ))}
    </div>
  );
};

export default PageIndicators;