import React, { useState, useMemo } from 'react';
import { UserProgress, ActivityType, Book, Activity, BookCategory } from '../types';
import ActivityLogItem from '../components/ActivityLogItem';
import BookCard from '../components/BookCard';
import { addActivity, updateBook, addBook } from '../services/dataService';

interface LibraryScreenProps {
  userProgress: UserProgress;
  updateProgress: (updates: Partial<UserProgress>) => void;
}

const LibraryScreen: React.FC<LibraryScreenProps> = ({ userProgress, updateProgress }) => {
  const { activities, books } = userProgress;

  // Calculate today's stats
  const today = new Date().toISOString().split('T')[0];
  const todayActivities = useMemo(() => activities.filter(
    (activity) => new Date(activity.timestamp).toISOString().split('T')[0] === today
  ), [activities, today]);

  const questionsSolvedToday = useMemo(() => todayActivities
    .filter(a => a.type === ActivityType.QUESTION)
    .reduce((sum, a) => sum + a.value, 0)
  , [todayActivities]);

  const pagesReadToday = useMemo(() => todayActivities
    .filter(a => a.type === ActivityType.READING)
    .reduce((sum, a) => sum + a.value, 0)
  , [todayActivities]);

  const handleAddQuestion = async () => {
    // In a real app, this would open a modal for input
    const numQuestions = parseInt(prompt('Kaç soru çözdün?') || '0');
    if (numQuestions > 0) {
      const newActivity: Activity = {
        id: `question-${Date.now()}`,
        type: ActivityType.QUESTION,
        description: `${numQuestions} soru çözüldü`,
        value: numQuestions,
        timestamp: Date.now(),
        subjectKey: userProgress.subjects.math.currentTopic !== 'Henüz başlanmadı' ? userProgress.subjects.math.key : undefined, // Example default
      };
      const addedActivity = await addActivity(newActivity);
      updateProgress({ activities: [addedActivity, ...activities] });
    }
  };

  const handleAddReading = async () => {
    // In a real app, this would open a modal for input
    const numPages = parseInt(prompt('Kaç sayfa okudun?') || '0');
    if (numPages > 0) {
      const newActivity: Activity = {
        id: `reading-${Date.now()}`,
        type: ActivityType.READING,
        description: `${numPages} sayfa okundu`,
        value: numPages,
        timestamp: Date.now(),
        subjectKey: undefined, // General reading
      };
      const addedActivity = await addActivity(newActivity);
      updateProgress({ activities: [addedActivity, ...activities] });
    }
  };

  const handleBookClick = (bookId: string) => {
    console.log(`Clicked on book: ${bookId}`);
    // In a real app, this might open a book detail view or a modal to update progress
    const bookToUpdate = books.find(b => b.id === bookId);
    if (bookToUpdate) {
      const pagesToAdvance = parseInt(prompt(`"${bookToUpdate.title}" için kaç sayfa ilerledin?`) || '0');
      if (pagesToAdvance > 0) {
        const newCurrentPage = Math.min(bookToUpdate.totalPages, bookToUpdate.currentPage + pagesToAdvance);
        updateBook(bookId, { currentPage: newCurrentPage }).then((updatedBook) => {
          if (updatedBook) {
            updateProgress({ books: books.map(b => b.id === updatedBook.id ? updatedBook : b) });
            // Also log as activity
            addActivity({
              id: `book-reading-${Date.now()}`,
              type: ActivityType.READING,
              description: `"${bookToUpdate.title}" kitabından ${pagesToAdvance} sayfa okundu.`,
              value: pagesToAdvance,
              timestamp: Date.now(),
            }).then((activity) => {
              updateProgress({ activities: [activity, ...activities] });
            });
          }
        });
      }
    }
  };

  const handleAddNewBook = async () => {
    const title = prompt('Yeni kitabın adı nedir?');
    const totalPages = parseInt(prompt('Toplam sayfa sayısı?') || '0');
    const category = prompt('Kategori (KPSS, TYT, GENEL)?') || 'GENEL'; // Add validation

    if (title && totalPages > 0) {
      const newBook: Book = {
        id: `book-${Date.now()}`,
        title,
        totalPages,
        currentPage: 0,
        category: category as BookCategory, // Type assertion, add proper validation in a real app
        coverGradient: `from-gray-600 via-slate-600 to-zinc-600`, // Default grey gradient
        progressPercentage: 0,
      };
      const addedBook = await addBook(newBook);
      updateProgress({ books: [...books, addedBook] });
    }
  };


  return (
    <div className="relative flex h-full min-h-screen w-full flex-col mx-auto max-w-md bg-background-dark shadow-2xl overflow-hidden">
      {/* Top App Bar */}
      <header className="sticky top-0 z-40 bg-background-dark/95 backdrop-blur-md border-b border-gray-800 px-5 py-3 flex items-center justify-between transition-colors duration-300">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary">
            <span className="material-symbols-outlined">local_library</span>
          </div>
          <h1 className="text-xl font-extrabold tracking-tight">Kütüphanem</h1>
        </div>
        <button className="relative group p-2 rounded-full hover:bg-gray-800 transition-colors">
          <span className="material-symbols-outlined text-gray-400">notifications</span>
          <span className="absolute top-2 right-2 w-2.5 h-2.5 bg-red-500 border-2 border-background-dark rounded-full"></span>
        </button>
      </header>

      {/* Daily Success Stats */}
      <section className="px-5 pt-6 pb-2">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xs font-bold text-gray-400 uppercase tracking-wider">Bugünkü Başarın</h2>
          <div className="flex items-center gap-1.5 px-3 py-1 bg-orange-500/10 rounded-full border border-orange-500/20">
            <span className="material-symbols-outlined text-lg text-orange-500 fill-1">
              local_fire_department
            </span>
            <span className="text-xs font-bold text-orange-500">{userProgress.dailyStreak} Gün Streak</span>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          {/* Stat Card 1 */}
          <div className="bg-surface-dark p-4 rounded-2xl border border-gray-800/60 shadow-sm flex flex-col gap-1 relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-16 h-16 bg-primary/5 rounded-bl-full -mr-2 -mt-2 transition-transform group-hover:scale-110"></div>
            <div className="flex items-start justify-between relative z-10">
              <span className="text-3xl font-bold text-primary tracking-tight">{questionsSolvedToday}</span>
              <span className="material-symbols-outlined text-gray-400">edit_note</span>
            </div>
            <p className="text-xs font-semibold text-gray-400 relative z-10">Soru Çözüldü</p>
          </div>
          {/* Stat Card 2 */}
          <div className="bg-surface-dark p-4 rounded-2xl border border-gray-800/60 shadow-sm flex flex-col gap-1 relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-16 h-16 bg-emerald-500/5 rounded-bl-full -mr-2 -mt-2 transition-transform group-hover:scale-110"></div>
            <div className="flex items-start justify-between relative z-10">
              <span className="text-3xl font-bold text-emerald-500 tracking-tight">{pagesReadToday}</span>
              <span className="material-symbols-outlined text-gray-400">auto_stories</span>
            </div>
            <p className="text-xs font-semibold text-gray-400 relative z-10">Sayfa Okundu</p>
          </div>
        </div>
      </section>

      {/* Quick Log Actions */}
      <section className="px-5 py-6">
        <h2 className="text-lg font-bold mb-4 tracking-tight">Hızlı Aktivite Kaydı</h2>
        <div className="flex gap-4">
          <button
            onClick={handleAddQuestion}
            className="flex-1 h-16 bg-primary hover:bg-blue-600 active:scale-[0.98] transition-all rounded-2xl flex items-center justify-center gap-2.5 text-white font-bold shadow-lg shadow-blue-500/25 border border-white/10"
          >
            <span className="material-symbols-outlined text-2xl">add_circle</span>
            <span>Soru Ekle</span>
          </button>
          <button
            onClick={handleAddReading}
            className="flex-1 h-16 bg-surface-dark border border-gray-700 hover:border-primary/50 hover:bg-gray-800 active:scale-[0.98] transition-all rounded-2xl flex items-center justify-center gap-2.5 text-white font-bold shadow-sm"
          >
            <span className="material-symbols-outlined text-2xl text-primary">bookmark_add</span>
            <span>Okuma Ekle</span>
          </button>
        </div>
      </section>

      {/* Books Shelf (Horizontal Scroll) */}
      <section className="py-2 border-t border-gray-800/50">
        <div className="px-5 flex items-center justify-between mb-4 mt-4">
          <h2 className="text-lg font-bold tracking-tight">Devam Eden Kitaplar</h2>
          <button
            onClick={handleAddNewBook}
            className="w-8 h-8 flex items-center justify-center rounded-full bg-surface-dark text-gray-400 hover:text-primary transition-colors"
          >
            <span className="material-symbols-outlined text-xl">add</span>
          </button>
        </div>
        <div className="flex overflow-x-auto gap-4 px-5 pb-6 hide-scrollbar snap-x">
          {books.map((book) => (
            <BookCard key={book.id} book={book} onClick={handleBookClick} />
          ))}
          {/* Add New Card Placeholder (if needed, but already handled by button above) */}
        </div>
      </section>

      {/* Recent Activity Log */}
      <section className="px-5 mb-4">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold tracking-tight">Son Hareketler</h2>
          <a className="text-sm text-primary font-bold hover:text-primary/80 transition-colors" href="#">
            Tümü
          </a>
        </div>
        <div className="flex flex-col gap-3">
          {activities
            .slice(0, 5) // Show only latest 5 for brevity
            .sort((a,b) => b.timestamp - a.timestamp) // Sort by most recent
            .map((activity) => (
              <ActivityLogItem key={activity.id} activity={activity} />
            ))}
            {activities.length === 0 && <p className="text-gray-400 text-center py-4">Henüz bir aktivite yok.</p>}
        </div>
      </section>
      <div className="h-28"></div> {/* Spacer for bottom nav */}
    </div>
  );
};

export default LibraryScreen;