import React from 'react';
import { Video } from '../types';

interface VideoCardProps {
  video: Video;
  onPlay: (video: Video) => void;
  onSave?: (videoId: string) => void;
  onMarkTough?: (videoId: string) => void;
  onShare?: (video: Video) => void;
}

const VideoCard: React.FC<VideoCardProps> = ({ video, onPlay, onSave, onMarkTough, onShare }) => {
  return (
    <div className="snap-start shrink-0 h-[calc(100vh-180px)] w-full px-4 mb-4 flex flex-col justify-end relative group">
      <div className="relative w-full h-full rounded-2xl overflow-hidden shadow-2xl bg-card-dark border border-white/5 ring-1 ring-white/10">
        {/* Main Video Thumbnail / Content */}
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url('${video.thumbnailUrl}')` }}
        ></div>
        {/* Dark Gradient Overlay for Readability */}
        <div className="absolute inset-0 glass-overlay pointer-events-none"></div>

        {/* Right Side Floating Actions */}
        <div className="absolute right-3 bottom-44 flex flex-col gap-5 items-center z-30">
          <button
            onClick={() => onSave?.(video.id)}
            className="flex flex-col items-center gap-1 group/btn"
          >
            <div
              className={`flex items-center justify-center w-10 h-10 rounded-full bg-white/10 backdrop-blur-md border border-white/10 text-white transition-transform active:scale-95 group-hover/btn:bg-white/20 ${
                video.isSaved ? 'text-primary' : ''
              }`}
            >
              <span className="material-symbols-outlined text-[22px]">{video.isSaved ? 'bookmark_added' : 'bookmark'}</span>
            </div>
            <span className="text-[10px] font-medium text-white/80 drop-shadow-md">Kaydet</span>
          </button>
          <button
            onClick={() => onMarkTough?.(video.id)}
            className="flex flex-col items-center gap-1 group/btn"
          >
            <div
              className={`flex items-center justify-center w-10 h-10 rounded-full bg-white/10 backdrop-blur-md border border-white/10 text-white transition-transform active:scale-95 group-hover/btn:bg-white/20 ${
                video.isTough ? 'text-orange-500' : ''
              }`}
            >
              <span className="material-symbols-outlined text-[22px]">{video.isTough ? 'flag' : 'flag'}</span>
            </div>
            <span className="text-[10px] font-medium text-white/80 drop-shadow-md">Zor</span>
          </button>
          <button
            onClick={() => onShare?.(video)}
            className="flex flex-col items-center gap-1 group/btn"
          >
            <div className="flex items-center justify-center w-10 h-10 rounded-full bg-white/10 backdrop-blur-md border border-white/10 text-white transition-transform active:scale-95 group-hover/btn:bg-white/20">
              <span className="material-symbols-outlined text-[22px]">share</span>
            </div>
            <span className="text-[10px] font-medium text-white/80 drop-shadow-md">Paylaş</span>
          </button>
        </div>

        {/* Bottom Content Info */}
        <div className="absolute bottom-0 left-0 right-0 p-5 z-20 flex flex-col gap-3">
          {/* Metadata Tags */}
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 rounded-md bg-primary/20 text-primary border border-primary/20 text-xs font-bold uppercase tracking-wider backdrop-blur-sm">
              {video.subjectKey.toUpperCase()}
            </span>
            <span className="px-2.5 py-1 rounded-md bg-white/10 text-white border border-white/10 text-xs font-medium backdrop-blur-sm flex items-center gap-1">
              <span className="material-symbols-outlined text-[14px]">play_circle</span>
              {video.type}
            </span>
          </div>

          {/* Title & Desc */}
          <div className="pr-12">
            <h2 className="text-2xl font-bold leading-tight tracking-tight text-white drop-shadow-lg mb-1">
              {video.title}
            </h2>
            <p className="text-text-secondary text-sm font-medium line-clamp-2 drop-shadow-md">
              {video.description}
            </p>
            <p className="text-white/60 text-xs mt-2 font-medium flex items-center gap-1">
              <span className="material-symbols-outlined text-[14px]">schedule</span> {video.durationInMinutes} Dakika
            </p>
          </div>

          {/* Primary Action Button */}
          <div className="pt-2">
            <button
              onClick={() => onPlay(video)}
              className="relative w-full group overflow-hidden rounded-xl bg-primary hover:bg-primary/90 transition-colors h-12 flex items-center justify-center shadow-[0_0_20px_rgba(19,127,236,0.3)]"
            >
              <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300"></div>
              <div className="relative flex items-center gap-2 text-white font-bold text-base tracking-wide">
                <span className="material-symbols-outlined text-[24px]">play_arrow</span>
                <span>Hemen İzle</span>
              </div>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VideoCard;