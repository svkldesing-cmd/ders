import React from 'react';
import { Activity } from '../types';
import ActivityLogItem from './ActivityLogItem';

interface DailyActivitySheetProps {
  date: Date;
  activities: Activity[];
  totalTimeInHours: number;
  onAddActivity: () => void;
  onClose: () => void; // Optional if sheet can be closed
}

const DailyActivitySheet: React.FC<DailyActivitySheetProps> = ({
  date,
  activities,
  totalTimeInHours,
  onAddActivity,
}) => {
  const formattedDate = date.toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' });

  // Example for specific activity types to match the design (quiz, play_circle, assignment)
  const renderActivityDetails = (activity: Activity) => {
    let icon = 'add_task';
    let color = 'gray-500';
    let valueText = '';
    let subjectText = activity.subjectKey ? activity.subjectKey.charAt(0).toUpperCase() + activity.subjectKey.slice(1) : '';

    switch (activity.type) {
      case 'QUESTION':
        icon = 'quiz';
        color = 'primary';
        valueText = `${activity.value} Soru`;
        break;
      case 'VIDEO':
        icon = 'play_circle';
        color = 'emerald-500';
        valueText = `${activity.value} Dk`;
        break;
      case 'TEST':
        icon = 'assignment';
        color = 'orange-500';
        valueText = `${activity.value} D`; // Assuming D for "Doğru" or "Deneme"
        break;
      case 'READING':
        icon = 'menu_book';
        color = 'purple-500';
        valueText = `${activity.value} Sayfa`;
        break;
      default:
        break;
    }

    return (
      <div className={`flex items-center gap-4 p-4 rounded-xl bg-surface-dark border border-white/5 hover:border-${color}/30 transition-colors`}>
        <div className={`size-12 rounded-full bg-${color}/20 flex items-center justify-center shrink-0 text-${color}`}>
          <span className="material-symbols-outlined">{icon}</span>
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex justify-between items-start mb-0.5">
            <h4 className="text-white font-semibold truncate">{subjectText} {activity.type === 'TEST' ? 'Deneme' : ''}</h4>
            <span className={`text-${color} font-bold text-sm`}>{valueText}</span>
          </div>
          <p className="text-gray-400 text-sm truncate">{activity.description}</p>
        </div>
        {activity.type === 'VIDEO' && ( // Only videos have navigation arrow in design
          <span className="material-symbols-outlined text-gray-600 text-xl">navigate_next</span>
        )}
      </div>
    );
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 transform transition-transform duration-300 ease-out translate-y-0 shadow-[0_-8px_30px_rgba(0,0,0,0.5)]">
      <div className="glass-panel w-full rounded-t-[2rem] p-6 pb-8 min-h-[50vh] flex flex-col">
        {/* Handle */}
        <div className="w-full flex justify-center mb-6">
          <div className="h-1.5 w-12 rounded-full bg-gray-600/50"></div>
        </div>

        {/* Sheet Header */}
        <div className="flex items-end justify-between mb-6">
          <div>
            <h3 className="text-white text-2xl font-bold tracking-tight">{formattedDate}</h3>
            <p className="text-gray-400 text-sm font-medium mt-1">Günlük Aktivite Özeti</p>
          </div>
          <div className="flex gap-2">
            <span className="px-3 py-1 rounded-full bg-primary/20 border border-primary/20 text-primary text-xs font-bold">
              {totalTimeInHours.toFixed(1)} Saat
            </span>
          </div>
        </div>

        {/* Log List */}
        <div className="flex-1 overflow-y-auto space-y-4 pr-2 custom-scrollbar"> {/* Added custom-scrollbar for desktop-like scroll */}
          {activities.length > 0 ? (
            activities.map((activity) => (
              <React.Fragment key={activity.id}>
                {renderActivityDetails(activity)}
              </React.Fragment>
            ))
          ) : (
            <p className="text-gray-400 text-center py-8">Bu güne ait bir aktivite bulunmuyor.</p>
          )}
        </div>

        {/* Bottom Action */}
        <div className="mt-6 pt-2 border-t border-white/5">
          <button
            onClick={onAddActivity}
            className="w-full h-12 bg-primary hover:bg-primary-dark text-white font-bold rounded-xl flex items-center justify-center gap-2 transition-colors shadow-lg shadow-primary/25"
          >
            <span className="material-symbols-outlined">add_circle</span>
            Aktivite Ekle
          </button>
        </div>
      </div>
    </div>
  );
};

export default DailyActivitySheet;