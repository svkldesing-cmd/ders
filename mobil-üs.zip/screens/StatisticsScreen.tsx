import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { UserProgress, Activity, ActivityType, Subject } from '../types';
import { getActivitiesByDate, getSubjects } from '../services/dataService';
import DailyActivitySheet from '../components/DailyActivitySheet';

interface StatisticsScreenProps {
  userProgress: UserProgress;
  updateProgress: (updates: Partial<UserProgress>) => void;
}

const StatisticsScreen: React.FC<StatisticsScreenProps> = ({ userProgress, updateProgress }) => {
  const { activities, dailyStreak, subjects } = userProgress;
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [dailyActivities, setDailyActivities] = useState<Activity[]>([]);
  const [showSheet, setShowSheet] = useState(false);
  const [currentMonth, setCurrentMonth] = useState(new Date());

  useEffect(() => {
    const fetchDailyData = async () => {
      const dateString = selectedDate.toISOString().split('T')[0];
      const fetchedActivities = await getActivitiesByDate(dateString);
      setDailyActivities(fetchedActivities);
    };
    fetchDailyData();
  }, [selectedDate]);

  const totalTimeInSeconds = useMemo(
    () =>
      activities.reduce((sum, activity) => {
        if (activity.type === ActivityType.VIDEO) {
          return sum + activity.value * 60; // Convert minutes to seconds
        }
        // Assuming question/reading activities also have a time cost, or ignore for time calculation
        return sum + 0;
      }, 0),
    [activities]
  );

  const totalQuestions = useMemo(
    () =>
      activities.reduce((sum, activity) => {
        if (activity.type === ActivityType.QUESTION || activity.type === ActivityType.TEST) {
          return sum + activity.value;
        }
        return sum + 0;
      }, 0),
    [activities]
  );

  const formatTotalTime = (totalSeconds: number) => {
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    return `${hours}s ${minutes}dk`;
  };

  const currentMonthName = currentMonth.toLocaleDateString('tr-TR', { month: 'long', year: 'numeric' });

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const numDays = lastDay.getDate();

    const days: (number | null)[] = [];
    // Fill leading empty days
    const startDay = firstDay.getDay(); // 0 for Sunday, 1 for Monday
    const offset = startDay === 0 ? 6 : startDay - 1; // Adjust for Monday start
    for (let i = 0; i < offset; i++) {
      days.push(null);
    }
    // Fill actual days
    for (let i = 1; i <= numDays; i++) {
      days.push(i);
    }
    return days;
  };

  const days = useMemo(() => getDaysInMonth(currentMonth), [currentMonth]);

  const hasActivityOnDay = useCallback(
    (day: number): { primary: boolean; emerald: boolean; orange: boolean } => {
      const dateString = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day)
        .toISOString()
        .split('T')[0];
      const dayActivities = activities.filter(
        (activity) => new Date(activity.timestamp).toISOString().split('T')[0] === dateString
      );

      return {
        primary: dayActivities.some((a) => a.type === ActivityType.QUESTION || a.type === ActivityType.TEST),
        emerald: dayActivities.some((a) => a.type === ActivityType.VIDEO),
        orange: dayActivities.some((a) => a.type === ActivityType.READING),
      };
    },
    [activities, currentMonth]
  );

  const handleDayClick = (day: number | null) => {
    if (day !== null) {
      const clickedDate = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day);
      setSelectedDate(clickedDate);
      setShowSheet(true);
    }
  };

  const handlePrevMonth = () => {
    setCurrentMonth((prev) => new Date(prev.getFullYear(), prev.getMonth() - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentMonth((prev) => new Date(prev.getFullYear(), prev.getMonth() + 1, 1));
  };

  const handleAddActivity = () => {
    // This would typically open a modal for adding activity details
    console.log('Open add activity modal for', selectedDate);
    // For now, we'll just close the sheet and expect the user to manually add.
    // In a real app, this would route to a dedicated activity logging screen or modal.
    setShowSheet(false);
  };

  const totalTimeDailySheet = useMemo(() => {
    return dailyActivities.reduce((sum, activity) => {
      if (activity.type === ActivityType.VIDEO) {
        return sum + activity.value; // In minutes
      }
      return sum;
    }, 0) / 60; // Convert to hours
  }, [dailyActivities]);


  return (
    <div className="relative flex h-screen w-full flex-col mx-auto max-w-md bg-background-dark overflow-hidden antialiased">
      {/* Background Decoration */}
      <div className="fixed top-[-10%] right-[-10%] w-[80vw] h-[80vw] rounded-full bg-primary/10 blur-[100px] pointer-events-none z-0"></div>
      <div className="fixed bottom-[-10%] left-[-10%] w-[60vw] h-[60vw] rounded-full bg-indigo-900/20 blur-[80px] pointer-events-none z-0"></div>

      {/* Top App Bar */}
      <header className="relative z-10 flex items-center justify-between p-4 pt-6 pb-2">
        <button className="flex size-10 items-center justify-center rounded-full active:bg-white/10 transition-colors">
          <span className="material-symbols-outlined text-white/90">arrow_back</span>
        </button>
        <h1 className="text-white text-lg font-bold leading-tight tracking-tight">İstatistikler</h1>
        <button className="flex size-10 items-center justify-center rounded-full active:bg-white/10 transition-colors">
          <span className="material-symbols-outlined text-white/90">more_vert</span>
        </button>
      </header>

      {/* Main Content Area (Scrollable) */}
      <main className="relative z-10 flex-1 overflow-y-auto pb-32">
        {/* Stats Overview Cards */}
        <section className="flex gap-3 px-4 py-2 overflow-x-auto no-scrollbar scroll-smooth">
          <div className="flex min-w-[140px] flex-1 flex-col gap-1 rounded-2xl p-4 glass relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-3 opacity-20">
              <span className="material-symbols-outlined text-3xl text-primary">timer</span>
            </div>
            <p className="text-gray-400 text-xs font-medium uppercase tracking-wider">Toplam Süre</p>
            <div className="flex items-baseline gap-1">
              <p className="text-white text-2xl font-bold tracking-tight">{formatTotalTime(totalTimeInSeconds)}</p>
            </div>
          </div>
          <div className="flex min-w-[140px] flex-1 flex-col gap-1 rounded-2xl p-4 glass relative overflow-hidden">
            <div className="absolute top-0 right-0 p-3 opacity-20">
              <span className="material-symbols-outlined text-3xl text-emerald-400">check_circle</span>
            </div>
            <p className="text-gray-400 text-xs font-medium uppercase tracking-wider">Soru Sayısı</p>
            <div className="flex items-baseline gap-1">
              <p className="text-white text-2xl font-bold tracking-tight">{totalQuestions}</p>
            </div>
          </div>
          <div className="flex min-w-[140px] flex-1 flex-col gap-1 rounded-2xl p-4 glass relative overflow-hidden">
            <div className="absolute top-0 right-0 p-3 opacity-20">
              <span className="material-symbols-outlined text-3xl text-orange-400">local_fire_department</span>
            </div>
            <p className="text-gray-400 text-xs font-medium uppercase tracking-wider">Seri</p>
            <div className="flex items-baseline gap-1">
              <p className="text-white text-2xl font-bold tracking-tight">{dailyStreak}</p>
              <p className="text-white/60 text-sm font-medium">Gün</p>
            </div>
          </div>
        </section>

        {/* Calendar Section */}
        <section className="px-4 py-6">
          <div className="glass rounded-3xl p-5 shadow-xl shadow-black/20">
            {/* Month Navigator */}
            <div className="flex items-center justify-between mb-6">
              <button
                onClick={handlePrevMonth}
                className="size-8 flex items-center justify-center rounded-full hover:bg-white/5 active:bg-white/10 transition-colors"
              >
                <span className="material-symbols-outlined text-gray-400 text-sm">arrow_back_ios_new</span>
              </button>
              <h2 className="text-white text-lg font-bold">{currentMonthName}</h2>
              <button
                onClick={handleNextMonth}
                className="size-8 flex items-center justify-center rounded-full hover:bg-white/5 active:bg-white/10 transition-colors"
              >
                <span className="material-symbols-outlined text-gray-400 text-sm">arrow_forward_ios</span>
              </button>
            </div>
            {/* Calendar Grid */}
            <div className="grid grid-cols-7 gap-y-4 gap-x-1">
              {/* Weekday Headers */}
              {['Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt', 'Paz'].map((day) => (
                <div
                  key={day}
                  className={`text-center text-[11px] font-bold uppercase tracking-wide ${
                    day === 'Cmt' || day === 'Paz' ? 'text-primary' : 'text-gray-500'
                  }`}
                >
                  {day}
                </div>
              ))}
              {/* Days */}
              {days.map((day, index) => {
                const isToday =
                  day !== null &&
                  new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day).toISOString().split('T')[0] ===
                    new Date().toISOString().split('T')[0];
                const isSelected =
                  day !== null &&
                  new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day).toISOString().split('T')[0] ===
                    selectedDate.toISOString().split('T')[0];
                const activityStatus = day !== null ? hasActivityOnDay(day) : null;
                const hasAnyActivity = activityStatus && (activityStatus.primary || activityStatus.emerald || activityStatus.orange);

                return (
                  <div key={index} className="flex flex-col items-center justify-center h-10 cursor-pointer relative" onClick={() => handleDayClick(day)}>
                    {day !== null && (
                      <span
                        className={`flex size-8 items-center justify-center rounded-full text-sm font-bold ${
                          isToday
                            ? 'bg-primary glow-primary shadow-lg text-white'
                            : isSelected
                            ? 'bg-surface-dark text-white ring-2 ring-primary/50 scale-110' // Selected but not today
                            : hasAnyActivity
                            ? 'bg-surface-dark border border-white/5 text-white' // Activity but not today/selected
                            : 'text-gray-400 hover:text-white transition-colors' // No activity
                        }`}
                      >
                        {day}
                      </span>
                    )}
                    {activityStatus && hasAnyActivity && (
                      <span className="absolute bottom-0.5 flex gap-0.5">
                        {activityStatus.primary && <span className="size-1 bg-primary rounded-full"></span>}
                        {activityStatus.emerald && <span className="size-1 bg-emerald-400 rounded-full"></span>}
                        {activityStatus.orange && <span className="size-1 bg-orange-400 rounded-full"></span>}
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
          <div className="mt-6 flex justify-center items-center gap-6">
            <div className="flex items-center gap-2">
              <span className="size-2 rounded-full bg-primary"></span>
              <span className="text-xs text-gray-400 font-medium">Soru Çözümü</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="size-2 rounded-full bg-emerald-400"></span>
              <span className="text-xs text-gray-400 font-medium">Konu Anlatımı</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="size-2 rounded-full bg-orange-400"></span>
              <span className="text-xs text-gray-400 font-medium">Okuma</span>
            </div>
          </div>
        </section>
      </main>

      {/* Bottom Sheet */}
      {showSheet && (
        <DailyActivitySheet
          date={selectedDate}
          activities={dailyActivities}
          totalTimeInHours={totalTimeDailySheet}
          onAddActivity={handleAddActivity}
          onClose={() => setShowSheet(false)}
        />
      )}
    </div>
  );
};

export default StatisticsScreen;