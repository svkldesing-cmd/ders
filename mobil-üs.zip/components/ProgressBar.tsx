import React from 'react';

interface ProgressBarProps {
  progress: number; // 0-100
  colorClass?: string; // Tailwind color, e.g., 'primary', 'orange-500'
  heightClass?: string; // Tailwind height, e.g., 'h-2', 'h-1.5'
  showGlow?: boolean;
}

const ProgressBar: React.FC<ProgressBarProps> = ({
  progress,
  colorClass = 'primary',
  heightClass = 'h-2',
  showGlow = true,
}) => {
  const clampedProgress = Math.max(0, Math.min(100, progress));
  const glowStyle = showGlow ? `shadow-[0_0_10px_rgba(var(--color-${colorClass}-rgb),0.5)]` : '';

  // Tailwind JIT compiles classes, so we need to ensure the full class names are present
  // If `colorClass` is 'primary', it becomes 'bg-primary' and 'from-primary to-blue-400'
  // If `colorClass` is 'orange-500', it becomes 'bg-orange-500' and 'from-orange-500 to-orange-400'
  const bgColor = `bg-${colorClass}`;
  const gradientFrom = `from-${colorClass}`;
  const gradientTo = colorClass === 'primary' ? 'to-blue-400' : `to-${colorClass.replace('-500', '-400')}`;


  return (
    <div className={`relative w-full bg-gray-800 rounded-full overflow-hidden ${heightClass}`}>
      <div
        className={`absolute top-0 left-0 h-full ${gradientFrom} ${gradientTo} ${bgColor} rounded-full ${glowStyle}`}
        style={{ width: `${clampedProgress}%` }}
      ></div>
    </div>
  );
};

export default ProgressBar;