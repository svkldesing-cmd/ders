import { Video, SubjectKey } from '../types';
import { MOCK_YOUTUBE_VIDEOS } from '../constants';

/**
 * Mocks fetching YouTube playlist items for a given playlist ID.
 * In a real application, this would call the YouTube Data API.
 */
export const getPlaylistVideos = async (
  playlistId: string,
  subjectKey: SubjectKey
): Promise<Video[]> => {
  // Simulate network delay
  await new Promise((resolve) => setTimeout(resolve, 1000));

  // In a real application, you would make an API call like this:
  // const API_KEY = process.env.REACT_APP_YOUTUBE_API_KEY; // This should be a backend call for security
  // const response = await fetch(
  //   `https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&playlistId=${playlistId}&maxResults=50&key=${API_KEY}`
  // );
  // const data = await response.json();
  // return data.items.map((item: any, index: number) => ({
  //   id: item.snippet.resourceId.videoId,
  //   title: item.snippet.title,
  //   description: item.snippet.description,
  //   thumbnailUrl: item.snippet.thumbnails.medium.url,
  //   durationInMinutes: 0, // YouTube Data API v3 playlistItems doesn't directly provide duration, requires separate videos API call
  //   subjectKey: subjectKey,
  //   type: VideoType.LECTURE, // Defaulting, would need to infer or allow user to set
  //   isCompleted: false,
  //   isTough: false,
  //   isSaved: false,
  //   order: index,
  // }));

  // For this mock, we just return predefined data based on subjectKey
  const mockVideos = MOCK_YOUTUBE_VIDEOS[subjectKey];

  if (mockVideos) {
    return mockVideos.map((video, index) => ({
      ...video,
      order: index, // Ensure order is set
      subjectKey: subjectKey,
    }));
  }

  return []; // Return empty array if no mock data
};
