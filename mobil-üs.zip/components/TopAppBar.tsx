import React from 'react';

interface TopAppBarProps {
  title: string;
  onBack?: () => void;
  rightContent?: React.ReactNode;
  showBackButton?: boolean;
}

const TopAppBar: React.FC<TopAppBarProps> = ({ title, onBack, rightContent, showBackButton = true }) => {
  return (
    <div className="flex items-center justify-between px-4 pt-5 pb-2 z-20 sticky top-0 bg-background-dark/95 backdrop-blur-sm">
      {showBackButton ? (
        <button
          onClick={onBack}
          className="flex items-center justify-center w-10 h-10 -ml-2 rounded-full text-slate-400 hover:bg-white/5 transition-colors"
        >
          <span className="material-symbols-outlined text-2xl">arrow_back</span>
        </button>
      ) : (
        <div className="w-10 h-10 -ml-2"></div> // Spacer to maintain alignment
      )}
      <h2 className="text-base font-bold leading-tight tracking-tight text-center flex-1">
        {title}
      </h2>
      <div className="w-10 flex justify-end">
        {rightContent}
      </div>
    </div>
  );
};

export default TopAppBar;