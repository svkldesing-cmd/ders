import React, { useState } from 'react';
import { StudyMode, StudyModeKey } from '../types';
import { STUDY_MODES } from '../constants';

interface StudyModesScreenProps {
  onSelectMode: (mode: StudyModeKey) => void;
  currentMode: StudyModeKey;
}

const StudyModesScreen: React.FC<StudyModesScreenProps> = ({ onSelectMode, currentMode }) => {
  const [selectedMode, setSelectedMode] = useState<StudyModeKey>(currentMode);

  const handleModeChange = (modeKey: StudyModeKey) => {
    setSelectedMode(modeKey);
  };

  const handleActivateMode = () => {
    onSelectMode(selectedMode);
  };

  return (
    <div className="relative flex h-full min-h-screen w-full flex-col overflow-x-hidden max-w-md mx-auto shadow-2xl bg-background-dark">
      {/* Ambient Background Gradient */}
      <div className="fixed top-0 left-0 w-full h-full overflow-hidden -z-10 pointer-events-none">
        <div className="absolute top-[-10%] right-[-10%] w-[300px] h-[300px] bg-primary/20 rounded-full blur-[100px]"></div>
        <div className="absolute bottom-[10%] left-[-10%] w-[250px] h-[250px] bg-purple-500/10 rounded-full blur-[80px]"></div>
      </div>

      {/* Top Header */}
      <header className="flex items-center justify-between px-6 pt-8 pb-4 z-10">
        <div className="flex flex-col">
          <span className="text-slate-400 text-sm font-medium">Merhaba, Öğrenci 👋</span>
          <h1 className="text-white text-xl font-bold leading-tight">Bugün nasıl hissediyorsun?</h1>
        </div>
        <div className="flex items-center justify-center p-0.5 rounded-full border border-white/10 bg-white/5">
          <div
            className="bg-center bg-no-repeat bg-cover rounded-full size-10"
            style={{ backgroundImage: 'url("https://lh3.googleusercontent.com/aida-public/AB6AXuBlBOdoTdX-5h1N8mAt0rvSa4qmnDRseilKiU3-qSocjBkmPWC3zFxiVO3pSgA-INdU9SOapmIz6ZnkXc33OkdX4BiFm-9S9dFHcjCtutemnz53i8BIoLW3NZrDfBh9z_92elKiuTKR33Cb9LdnOW5p4axSa3kGUS0nZcd6g9Ev_JSiMl1qMITCCthCj11iJa8QKA6m6BOUG5fX3hK5xRyGopRCTdLZR9JYoAD5ejiIwN7cYveA9bSxY_6aWc3uaI4zgw0rNVSaeoRl")' }}
          ></div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex flex-col px-4 gap-5 pb-24 z-10">
        <div className="px-2">
          <p className="text-slate-400 text-sm font-normal leading-relaxed">
            Enerjine en uygun çalışma modunu seç, günlük hedeflerini senin için optimize edelim.
          </p>
        </div>

        {STUDY_MODES.map((mode: StudyMode) => (
          <label key={mode.key} className="group relative cursor-pointer">
            <input
              type="radio"
              name="study_mode"
              value={mode.key}
              checked={selectedMode === mode.key}
              onChange={() => handleModeChange(mode.key)}
              className="peer sr-only"
            />
            <div
              className={`rounded-2xl p-4 flex items-stretch gap-4 transition-all duration-300 ${
                selectedMode === mode.key
                  ? 'glass-card-active peer-checked:ring-0'
                  : 'glass-card hover:bg-slate-800/60 peer-checked:border-primary'
              }`}
            >
              {/* Icon/Visual */}
              <div
                className={`flex-shrink-0 w-20 h-20 rounded-xl bg-gradient-to-br from-${mode.colorClass}/20 to-${mode.colorClass.replace('-400', '-500')}/20 flex items-center justify-center border border-${mode.colorClass}/30`}
              >
                <span className={`material-symbols-outlined text-${mode.colorClass} text-4xl fill-1`}>
                  {mode.icon}
                </span>
              </div>
              {/* Content */}
              <div className="flex-1 flex flex-col justify-center">
                <div className="flex justify-between items-start mb-1">
                  <h3 className="text-white text-lg font-bold">{mode.name}</h3>
                  <span
                    className={`material-symbols-outlined text-xl transition-colors ${
                      selectedMode === mode.key ? 'text-primary' : 'text-slate-600 group-hover:text-slate-400'
                    }`}
                  >
                    {selectedMode === mode.key ? 'check_circle' : 'radio_button_unchecked'}
                  </span>
                </div>
                <p className="text-slate-300 text-xs font-medium leading-relaxed">
                  {mode.description}
                </p>
              </div>
            </div>
            {/* Glow effect for active card */}
            {selectedMode === mode.key && (
              <div className="absolute inset-0 -z-10 rounded-2xl bg-primary/20 blur-md opacity-0 peer-checked:opacity-100 transition-opacity duration-500 animate-fade-in-up"></div>
            )}
          </label>
        ))}
      </main>

      {/* Fixed Bottom CTA */}
      <div className="fixed bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-background-dark via-background-dark/95 to-transparent z-20 max-w-md mx-auto">
        <button
          onClick={handleActivateMode}
          className="w-full bg-primary hover:bg-blue-600 active:scale-[0.98] transition-all text-white font-bold text-base py-4 px-6 rounded-xl shadow-[0_0_20px_rgba(19,127,236,0.4)] flex items-center justify-center gap-2"
        >
          <span>Modu Etkinleştir</span>
          <span className="material-symbols-outlined text-lg">arrow_forward</span>
        </button>
      </div>
    </div>
  );
};

export default StudyModesScreen;