import { INITIAL_SUBJECTS, STUDY_MODES, MOCK_YOUTUBE_VIDEOS, MOCK_BOOKS } from '../constants';
import { SubjectKey, UserProgress, StudyModeKey, Subject, Video, Activity, Book } from '../types';

const LOCAL_STORAGE_KEY = 'mobilUsProgress';

/**
 * Initializes or loads user progress from local storage.
 * If no progress is found, it creates a default state.
 */
export const loadUserProgress = (): UserProgress => {
  try {
    const storedProgress = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (storedProgress) {
      const parsedProgress: UserProgress = JSON.parse(storedProgress);

      // Ensure all subjects are initialized, especially for new fields
      const subjectsWithDefaults: { [key in SubjectKey]?: Subject } = { ...INITIAL_SUBJECTS };
      if (parsedProgress.subjects) {
        for (const key in parsedProgress.subjects) {
          const subjectKey = key as SubjectKey;
          subjectsWithDefaults[subjectKey] = {
            ...INITIAL_SUBJECTS[subjectKey],
            ...parsedProgress.subjects[subjectKey],
          };
        }
      }

      // Ensure all videos are loaded from mock or existing state
      const allVideos: { [videoId: string]: Video } = {};
      for (const subjectKey in MOCK_YOUTUBE_VIDEOS) {
        const videos = MOCK_YOUTUBE_VIDEOS[subjectKey as SubjectKey];
        if (videos) {
          videos.forEach(video => {
            allVideos[video.id] = { ...video };
          });
        }
      }
      if (parsedProgress.videos) {
        for (const videoId in parsedProgress.videos) {
          allVideos[videoId] = { ...allVideos[videoId], ...parsedProgress.videos[videoId] };
        }
      }

      // Ensure books are consistent
      const booksWithDefaults: Book[] = MOCK_BOOKS.map(mockBook => {
        const existingBook = parsedProgress.books?.find(b => b.id === mockBook.id);
        return existingBook ? { ...mockBook, ...existingBook } : mockBook;
      });


      return {
        ...parsedProgress,
        subjects: subjectsWithDefaults,
        videos: allVideos,
        books: booksWithDefaults,
        // Provide default values for new fields if they don't exist
        dailyStreak: parsedProgress.dailyStreak ?? 0,
        dailyGoalVideos: parsedProgress.dailyGoalVideos ?? 5,
        dailyCompletedVideos: parsedProgress.dailyCompletedVideos ?? 0,
        lastLoginDate: parsedProgress.lastLoginDate ?? new Date().toISOString().split('T')[0],
      };
    }
  } catch (error) {
    console.error('Error loading user progress from local storage:', error);
    // Fallback to default state if parsing fails
  }

  // Default initial state if nothing is found or an error occurs
  const initialVideos: { [videoId: string]: Video } = {};
  for (const subjectKey in MOCK_YOUTUBE_VIDEOS) {
    const videos = MOCK_YOUTUBE_VIDEOS[subjectKey as SubjectKey];
    if (videos) {
      videos.forEach(video => {
        initialVideos[video.id] = { ...video };
      });
    }
  }

  return {
    subjects: INITIAL_SUBJECTS,
    videos: initialVideos,
    studyMode: StudyModeKey.GOLDEN_DAY,
    activities: [],
    books: MOCK_BOOKS,
    dailyStreak: 0,
    dailyGoalVideos: 5,
    dailyCompletedVideos: 0,
    lastLoginDate: new Date().toISOString().split('T')[0],
  };
};

/**
 * Saves user progress to local storage.
 */
export const saveUserProgress = (progress: UserProgress): void => {
  try {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(progress));
  } catch (error) {
    console.error('Error saving user progress to local storage:', error);
  }
};

/**
 * Updates a specific subject's data.
 */
export const updateSubject = (subjectKey: SubjectKey, updates: Partial<Subject>): Promise<Subject> => {
  return new Promise((resolve) => {
    const progress = loadUserProgress();
    const updatedSubject = {
      ...(progress.subjects[subjectKey] || INITIAL_SUBJECTS[subjectKey]),
      ...updates,
    };
    progress.subjects = {
      ...progress.subjects,
      [subjectKey]: updatedSubject,
    };
    saveUserProgress(progress);
    resolve(updatedSubject);
  });
};

/**
 * Fetches all subjects for the current user.
 * Simulates a database read.
 */
export const getSubjects = (): Promise<Subject[]> => {
  return new Promise((resolve) => {
    const progress = loadUserProgress();
    const subjectsArray = Object.values(progress.subjects).filter(s => s !== undefined) as Subject[];
    resolve(subjectsArray);
  });
};

/**
 * Updates a specific video's data.
 */
export const updateVideo = (videoId: string, updates: Partial<Video>): Promise<Video> => {
  return new Promise((resolve) => {
    const progress = loadUserProgress();
    const updatedVideo = {
      ...progress.videos[videoId],
      ...updates,
    };
    progress.videos = {
      ...progress.videos,
      [videoId]: updatedVideo,
    };
    saveUserProgress(progress);
    resolve(updatedVideo);
  });
};

/**
 * Adds a new activity to the user's log.
 */
export const addActivity = (activity: Activity): Promise<Activity> => {
  return new Promise((resolve) => {
    const progress = loadUserProgress();
    progress.activities.push(activity);
    saveUserProgress(progress);
    resolve(activity);
  });
};

/**
 * Gets all activities for a specific date (YYYY-MM-DD).
 */
export const getActivitiesByDate = (dateString: string): Promise<Activity[]> => {
  return new Promise((resolve) => {
    const progress = loadUserProgress();
    const activitiesOnDate = progress.activities.filter(
      (activity) => new Date(activity.timestamp).toISOString().split('T')[0] === dateString
    ).sort((a,b) => b.timestamp - a.timestamp); // Sort by most recent first
    resolve(activitiesOnDate);
  });
};

/**
 * Updates a specific book's data.
 */
export const updateBook = (bookId: string, updates: Partial<Book>): Promise<Book> => {
  return new Promise((resolve) => {
    const progress = loadUserProgress();
    const bookIndex = progress.books.findIndex(book => book.id === bookId);
    if (bookIndex > -1) {
      const updatedBook = {
        ...progress.books[bookIndex],
        ...updates,
      };
      // Recalculate progress percentage
      if (updates.currentPage !== undefined || updates.totalPages !== undefined) {
        updatedBook.progressPercentage = Math.round((updatedBook.currentPage / updatedBook.totalPages) * 100);
      }
      progress.books[bookIndex] = updatedBook;
      saveUserProgress(progress);
      resolve(updatedBook);
    } else {
      console.warn(`Book with ID ${bookId} not found.`);
      resolve(null as any); // Resolve with null or reject, depending on desired error handling
    }
  });
};

/**
 * Adds a new book.
 */
export const addBook = (newBook: Book): Promise<Book> => {
  return new Promise((resolve) => {
    const progress = loadUserProgress();
    progress.books.push(newBook);
    saveUserProgress(progress);
    resolve(newBook);
  });
};

/**
 * Updates the daily streak and last login date.
 */
export const updateDailyStreak = (): Promise<number> => {
  return new Promise((resolve) => {
    const progress = loadUserProgress();
    const today = new Date().toISOString().split('T')[0];
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayString = yesterday.toISOString().split('T')[0];

    let newStreak = progress.dailyStreak;
    if (progress.lastLoginDate !== today) {
      if (progress.lastLoginDate === yesterdayString) {
        newStreak += 1; // Continue streak
      } else {
        newStreak = 1; // Start new streak if not consecutive
      }
      progress.lastLoginDate = today;
      progress.dailyStreak = newStreak;
      saveUserProgress(progress);
    }
    resolve(newStreak);
  });
};

/**
 * Resets daily completed videos and goal if new day.
 */
export const resetDailyProgress = (): Promise<void> => {
  return new Promise((resolve) => {
    const progress = loadUserProgress();
    const today = new Date().toISOString().split('T')[0];
    if (progress.lastLoginDate !== today) {
      progress.dailyCompletedVideos = 0;
      progress.lastLoginDate = today; // Update last login date
      saveUserProgress(progress);
    }
    resolve();
  });
};

/**
 * Increments daily completed videos.
 */
export const incrementDailyCompletedVideos = (): Promise<number> => {
  return new Promise((resolve) => {
    const progress = loadUserProgress();
    progress.dailyCompletedVideos += 1;
    saveUserProgress(progress);
    resolve(progress.dailyCompletedVideos);
  });
};
