import React from 'react';
import { Subject } from '../types';
import ProgressBar from './ProgressBar';

interface CourseProgressCardProps {
  subject: Subject;
  onClick?: (subjectKey: string) => void;
}

const CourseProgressCard: React.FC<CourseProgressCardProps> = ({ subject, onClick }) => {
  const isActive = subject.completedVideos > 0 || subject.playlistLink !== ''; // Consider active if any videos completed or a playlist link exists

  return (
    <div
      className={`glass-panel rounded-xl p-4 hover:bg-white/[0.03] transition-colors cursor-pointer active:scale-[0.98] duration-200 ${
        !isActive ? 'opacity-80' : ''
      }`}
      onClick={() => onClick?.(subject.key)}
    >
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3">
          <div
            className={`size-10 rounded-lg bg-${subject.colorClass}/20 flex items-center justify-center text-${subject.colorClass} border border-${subject.colorClass}/20 ${
              !isActive ? 'grayscale text-blue-400/50 border-blue-500/10' : ''
            }`}
          >
            <span className="material-symbols-outlined">{subject.icon}</span>
          </div>
          <div>
            <h4
              className={`text-base font-bold leading-tight ${
                !isActive ? 'text-white/70' : 'text-white'
              }`}
            >
              {subject.name}
            </h4>
            <p className={`text-xs mt-0.5 ${!isActive ? 'text-gray-500' : 'text-gray-400'}`}>
              {subject.currentTopic}
            </p>
          </div>
        </div>
        <span
          className={`text-sm font-bold ${
            !isActive ? 'text-gray-500' : 'text-white'
          }`}
        >
          %{subject.progressPercentage}
        </span>
      </div>
      <div className="flex items-center justify-between text-xs text-gray-400 mb-2">
        <span>
          {subject.completedVideos}/{subject.totalVideos} Video İzledi
        </span>
        {isActive && subject.completedVideos < subject.totalVideos && (
          <span className={`text-${subject.colorClass} flex items-center gap-1`}>
            <span className="material-symbols-outlined text-[14px]">play_circle</span> Devam Et
          </span>
        )}
      </div>
      <ProgressBar
        progress={subject.progressPercentage}
        colorClass={isActive ? subject.colorClass : 'gray-600'}
        heightClass="h-2"
        showGlow={isActive}
      />
    </div>
  );
};

export default CourseProgressCard;