import React, { useState } from 'react';
import TopAppBar from '../components/TopAppBar';
import PageIndicators from '../components/PageIndicators';
import SubjectPlaylistInput from '../components/SubjectPlaylistInput';
import { Subject, SubjectKey } from '../types';
import { INITIAL_SUBJECTS } from '../constants';

interface OnboardingScreenProps {
  onComplete: (subjects: { [key in SubjectKey]: Subject }) => void;
  initialSubjects: { [key in SubjectKey]: Subject };
}

const OnboardingScreen: React.FC<OnboardingScreenProps> = ({ onComplete, initialSubjects }) => {
  const [subjects, setSubjects] = useState<{ [key in SubjectKey]: Subject }>(
    initialSubjects || INITIAL_SUBJECTS
  );

  const handlePlaylistLinkChange = (subjectKey: string, link: string) => {
    setSubjects((prevSubjects) => ({
      ...prevSubjects,
      [subjectKey as SubjectKey]: {
        ...prevSubjects[subjectKey as SubjectKey],
        playlistLink: link,
      },
    }));
  };

  const handleSubmit = () => {
    // Here, in a real app, you would validate links and potentially fetch playlist data.
    // For this mock, we just pass the updated subject links.
    onComplete(subjects);
  };

  // Extract subjects as an array to map over for rendering
  const subjectList = Object.values(subjects) as Subject[];

  return (
    <div className="relative flex h-full min-h-screen w-full flex-col overflow-hidden max-w-md mx-auto shadow-2xl bg-background-dark">
      {/* Top App Bar */}
      <TopAppBar title="Kurulum Sihirbazı" showBackButton={false} />

      {/* Page Indicators */}
      <PageIndicators totalSteps={4} currentStep={1} />

      {/* Scrollable Content Area */}
      <div className="flex-1 overflow-y-auto no-scrollbar px-5 pb-36 pt-2">
        {/* Headline Text */}
        <div className="mb-6 animate-fade-in-up">
          <h1 className="text-[28px] font-bold leading-tight mb-3 tracking-[-0.02em] bg-gradient-to-br from-white to-slate-400 bg-clip-text text-transparent">
            Favori Hocalarını Ekle
          </h1>
          {/* Body Text */}
          <p className="text-slate-400 text-sm font-medium leading-relaxed">
            KPSS hazırlık sürecinde takip ettiğin YouTube oynatma listelerini buraya ekle, akışını
            biz kuralım.
          </p>
          <button className="mt-3 text-primary text-xs font-bold flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-primary/10 hover:bg-primary/20 transition-colors w-fit">
            <span className="material-symbols-outlined text-[18px]">help</span>
            Playlist linki nasıl alınır?
          </button>
        </div>

        {/* Form Fields */}
        <div className="flex flex-col gap-4">
          {subjectList.map((subject) => (
            <SubjectPlaylistInput
              key={subject.key}
              subject={subject}
              onPlaylistLinkChange={handlePlaylistLinkChange}
            />
          ))}
        </div>
      </div>

      {/* Sticky Bottom Action Bar */}
      <div className="absolute bottom-0 left-0 right-0 p-5 bg-background-dark/80 backdrop-blur-xl border-t border-white/5 z-30">
        <div className="flex items-center gap-3">
          <button
            type="button"
            className="flex-1 py-3.5 px-4 rounded-xl text-sm font-bold text-slate-400 hover:text-white hover:bg-white/5 transition-colors"
          >
            Daha Sonra
          </button>
          <button
            type="button"
            onClick={handleSubmit}
            className="flex-[2] py-3.5 px-4 rounded-xl bg-primary hover:bg-primary/90 active:scale-[0.98] text-white text-sm font-bold shadow-lg shadow-primary/25 transition-all flex items-center justify-center gap-2 group"
          >
            Kaydet ve İlerle
            <span className="material-symbols-outlined text-lg group-hover:translate-x-0.5 transition-transform">
              arrow_forward
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default OnboardingScreen;