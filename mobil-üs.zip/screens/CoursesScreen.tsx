import React, { useMemo } from 'react';
import { UserProgress, SubjectKey, Subject } from '../types';
import CourseProgressCard from '../components/CourseProgressCard';
import ProgressBar from '../components/ProgressBar';

interface CoursesScreenProps {
  userProgress: UserProgress;
  updateProgress: (updates: Partial<UserProgress>) => void;
}

const CoursesScreen: React.FC<CoursesScreenProps> = ({ userProgress, updateProgress }) => {
  const { subjects } = userProgress;

  const allSubjectsArray = useMemo(() => Object.values(subjects) as Subject[], [subjects]);

  const totalVideosOverall = useMemo(
    () => allSubjectsArray.reduce((sum, s) => sum + s.totalVideos, 0),
    [allSubjectsArray]
  );
  const completedVideosOverall = useMemo(
    () => allSubjectsArray.reduce((sum, s) => sum + s.completedVideos, 0),
    [allSubjectsArray]
  );

  const overallProgressPercentage = useMemo(
    () => (totalVideosOverall > 0 ? Math.round((completedVideosOverall / totalVideosOverall) * 100) : 0),
    [completedVideosOverall, totalVideosOverall]
  );

  const handleCourseClick = (subjectKey: SubjectKey) => {
    // Navigate to a detailed course view or update the current playing video
    console.log(`Clicked on course: ${subjectKey}`);
    // In a full app, this might navigate to a subject-specific screen
    // For this example, we'll just log it.
  };

  const lastWatchedSubjectKey = useMemo(() => {
    let latestWatchedTimestamp = 0;
    let lastSubjectKey: SubjectKey | undefined = undefined;
    for (const video of Object.values(userProgress.videos)) {
      if (video.isCompleted && video.watchedAt && video.watchedAt > latestWatchedTimestamp) {
        latestWatchedTimestamp = video.watchedAt;
        lastSubjectKey = video.subjectKey;
      }
    }
    return lastSubjectKey;
  }, [userProgress.videos]);

  const handleContinueLastLesson = () => {
    if (lastWatchedSubjectKey) {
      console.log(`Continuing last lesson in ${lastWatchedSubjectKey}`);
      // In a full app, this would change screen to SmartFeed and focus on next video for this subject
      // For this example, we will just log.
    } else {
      console.log("No last lesson to continue.");
    }
  };

  return (
    <div className="relative flex h-screen w-full flex-col mx-auto max-w-md bg-background-dark overflow-hidden shadow-2xl">
      {/* Sticky Header */}
      <header className="glass-header absolute top-0 left-0 right-0 z-50 px-5 pt-12 pb-4 flex items-center justify-between">
        <button className="text-white/80 hover:text-white transition-colors p-1 rounded-full hover:bg-white/5">
          <span className="material-symbols-outlined !text-[28px]">menu</span>
        </button>
        <h1 className="text-lg font-bold tracking-tight text-white">Derslerim</h1>
        <div className="relative">
          <button className="flex items-center justify-center size-9 rounded-full bg-primary/20 border border-primary/30 overflow-hidden">
            <img
              alt="User Profile"
              className="w-full h-full object-cover"
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuDbSFLYNfc_g9ItKyMrVoL2_yd2rCLlGsbpgCAF7ppZ-lRNtNGDYFG_aUClfMrSff-F_fnhHw0QqwjzDgLc5aWZ6HGgbHNTAgKfYv_Fp9m3LOxipc4XMIKg43p-tLqYrkVwOerYZ9CSYAbVmdREaLV5PDY7Uf1n2_JcCS8V6jxvxO31HX_h7pMaVO"
            />
          </button>
          <div className="absolute -top-1 -right-1 size-3 bg-red-500 rounded-full border-2 border-[#101922]"></div>
        </div>
      </header>

      {/* Main Scrollable Content */}
      <main className="flex-1 overflow-y-auto no-scrollbar pt-28 pb-24 px-5">
        {/* Greeting & Summary */}
        <div className="mb-8 animate-fade-in-up">
          <h2 className="text-3xl font-bold text-white mb-2">Merhaba, Ahmet 👋</h2>
          <p className="text-gray-400 text-sm leading-relaxed">
            KPSS Maratonunda harika gidiyorsun! Bugün hedefine bir adım daha yaklaşmaya hazır mısın?
          </p>
        </div>

        {/* Global Progress Card (Hero) */}
        <div className="glass-panel rounded-2xl p-5 mb-8 relative overflow-hidden group">
          {/* Abstract Background Gradient */}
          <div className="absolute -top-10 -right-10 size-40 bg-primary/20 rounded-full blur-3xl group-hover:bg-primary/30 transition-all duration-700"></div>
          <div className="flex items-center justify-between mb-4 relative z-10">
            <div>
              <p className="text-gray-400 text-xs font-semibold uppercase tracking-wider mb-1">
                Genel İlerleme
              </p>
              <h3 className="text-2xl font-bold text-white">
                %{overallProgressPercentage} Tamamlandı
              </h3>
            </div>
            <div className="size-12 rounded-full bg-primary/20 flex items-center justify-center text-primary border border-primary/30">
              <span className="material-symbols-outlined">trending_up</span>
            </div>
          </div>
          {/* Global Progress Bar */}
          <ProgressBar
            progress={overallProgressPercentage}
            colorClass="primary"
            heightClass="h-3"
            showGlow={true}
          />
          <div className="mt-3 flex justify-between items-center text-xs text-gray-400">
            <span>Tüm Dersler Ortalaması</span>
            <span className="text-white font-medium">
              {completedVideosOverall}/{totalVideosOverall} Konu
            </span>
          </div>
        </div>

        {/* Section Title */}
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold text-white">Ders Bazlı İlerleme</h3>
          <button className="text-xs font-medium text-primary hover:text-primary/80 transition-colors">
            Tümünü Gör
          </button>
        </div>

        {/* Course List */}
        <div className="flex flex-col gap-4">
          {allSubjectsArray.map((subject) => (
            <CourseProgressCard key={subject.key} subject={subject} onClick={handleCourseClick} />
          ))}
        </div>

        {/* Empty spacer for bottom nav */}
        <div className="h-8"></div>
      </main>

      {/* Floating Action Button Context: Continue Last Lesson */}
      {lastWatchedSubjectKey && (
        <div className="absolute bottom-24 right-5 z-40">
          <button
            onClick={handleContinueLastLesson}
            className="flex items-center gap-2 bg-primary hover:bg-primary/90 text-white px-5 py-3 rounded-full shadow-[0_8px_20px_rgba(19,127,236,0.5)] transition-all active:scale-95 group"
          >
            <span className="text-sm font-bold">Derse Devam Et</span>
            <span className="material-symbols-outlined text-[20px] group-hover:translate-x-1 transition-transform">
              arrow_forward
            </span>
          </button>
        </div>
      )}
    </div>
  );
};

export default CoursesScreen;