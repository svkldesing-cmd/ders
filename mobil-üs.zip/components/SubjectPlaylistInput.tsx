import React, { useState } from 'react';
import { Subject } from '../types';

interface SubjectPlaylistInputProps {
  subject: Subject;
  onPlaylistLinkChange: (subjectKey: string, link: string) => void;
}

const SubjectPlaylistInput: React.FC<SubjectPlaylistInputProps> = ({
  subject,
  onPlaylistLinkChange,
}) => {
  const [inputValue, setInputValue] = useState(subject.playlistLink);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputValue(e.target.value);
  };

  const handlePasteClick = async () => {
    try {
      const text = await navigator.clipboard.readText();
      setInputValue(text);
      onPlaylistLinkChange(subject.key, text);
    } catch (err) {
      console.error('Failed to read clipboard contents: ', err);
    }
  };

  const handleBlur = () => {
    // Update parent state only on blur or paste to prevent excessive re-renders during typing
    onPlaylistLinkChange(subject.key, inputValue);
  };

  return (
    <div className="glass-panel rounded-2xl p-4 transition-all duration-300 hover:bg-surface-dark/60 group">
      <label className="flex flex-col w-full cursor-text">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-3">
            <div
              className={`w-10 h-10 rounded-xl bg-${subject.colorClass}/10 flex items-center justify-center border border-${subject.colorClass}/20 text-xl`}
            >
              {subject.emoji}
            </div>
            <span className="text-base font-semibold text-slate-800 dark:text-slate-100">
              {subject.name}
            </span>
          </div>
        </div>
        <div className="flex w-full items-center rounded-xl glass-input overflow-hidden h-12">
          <span className="material-symbols-outlined pl-3.5 text-slate-500 text-[20px]">link</span>
          <input
            className="form-input flex-1 bg-transparent border-none text-sm text-slate-900 dark:text-white placeholder:text-slate-500/80 focus:ring-0 px-3 h-full leading-normal"
            placeholder="YouTube Playlist Linki"
            type="url"
            value={inputValue}
            onChange={handleInputChange}
            onBlur={handleBlur}
          />
          <button
            onClick={handlePasteClick}
            type="button"
            className="mr-1.5 px-3 py-1.5 rounded-lg text-primary hover:bg-primary/10 transition-colors text-xs font-bold uppercase tracking-wide"
          >
            Yapıştır
          </button>
        </div>
      </label>
    </div>
  );
};

export default SubjectPlaylistInput;