import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { UserProgress, Video, Subject, SubjectKey, StudyModeKey, ActivityType } from '../types';
import { MOCK_YOUTUBE_VIDEOS, STUDY_MODES } from '../constants';
import VideoCard from '../components/VideoCard';
import TimelineVideoItem from '../components/TimelineVideoItem';
import {
  updateVideo,
  updateSubject,
  addActivity,
  incrementDailyCompletedVideos,
} from '../services/dataService';
import ProgressBar from '../components/ProgressBar';

interface SmartFeedScreenProps {
  userProgress: UserProgress;
  updateProgress: (updates: Partial<UserProgress>) => void;
}

const SmartFeedScreen: React.FC<SmartFeedScreenProps> = ({ userProgress, updateProgress }) => {
  const { subjects, videos, studyMode, dailyGoalVideos, dailyCompletedVideos } = userProgress;

  // Filter and sort videos based on study mode and completion status
  const activeVideos = useMemo(() => {
    const currentStudyMode = STUDY_MODES.find((mode) => mode.key === studyMode);
    if (!currentStudyMode) return [];

    const allowedSubjects =
      currentStudyMode.activeSubjects === 'all'
        ? Object.keys(subjects)
        : currentStudyMode.activeSubjects === 'none'
        ? []
        : currentStudyMode.activeSubjects;

    const filteredVideos = Object.values(videos).filter((video) => {
      // Ensure video is not null and subjectKey is allowed
      if (!video || !allowedSubjects.includes(video.subjectKey)) return false;
      return true;
    });

    // Sort by subject, then by order
    return filteredVideos.sort((a, b) => {
      const subjectA = a.subjectKey.localeCompare(b.subjectKey);
      if (subjectA !== 0) return subjectA;
      return a.order - b.order;
    });
  }, [videos, subjects, studyMode]);

  const [activeVideoIndex, setActiveVideoIndex] = useState(() => {
    // Find the first uncompleted video
    const firstUncompletedIndex = activeVideos.findIndex((video) => !video.isCompleted);
    return firstUncompletedIndex !== -1 ? firstUncompletedIndex : 0;
  });

  const activeVideo = activeVideos[activeVideoIndex];

  const handleVideoCompleted = useCallback(async () => {
    if (!activeVideo) return;

    // 1. Mark video as completed
    const updatedVideo = await updateVideo(activeVideo.id, {
      isCompleted: true,
      watchedAt: Date.now(),
    });
    updateProgress({
      videos: { ...userProgress.videos, [activeVideo.id]: updatedVideo },
    });

    // 2. Update subject progress
    const subject = subjects[activeVideo.subjectKey];
    if (subject) {
      const newCompletedVideos = subject.completedVideos + 1;
      const newProgressPercentage = Math.round((newCompletedVideos / subject.totalVideos) * 100);
      const updatedSubject = await updateSubject(subject.key, {
        completedVideos: newCompletedVideos,
        progressPercentage: newProgressPercentage,
        currentVideoIndex: subject.currentVideoIndex + 1,
        lastWatchedVideoId: activeVideo.id,
        currentTopic: activeVideos[activeVideoIndex + 1]?.title || 'Tamamlandı',
      });
      updateProgress({
        subjects: { ...subjects, [subject.key]: updatedSubject },
      });
    }

    // 3. Add activity log
    await addActivity({
      id: `activity-${Date.now()}`,
      type: ActivityType.VIDEO,
      subjectKey: activeVideo.subjectKey,
      description: activeVideo.title,
      value: activeVideo.durationInMinutes,
      timestamp: Date.now(),
    });

    // 4. Increment daily completed videos
    const newDailyCompleted = await incrementDailyCompletedVideos();
    updateProgress({ dailyCompletedVideos: newDailyCompleted });

    // 5. Move to the next video
    setActiveVideoIndex((prevIndex) => {
      const nextIndex = prevIndex + 1;
      if (nextIndex < activeVideos.length) {
        return nextIndex;
      }
      return prevIndex; // Stay on the last video if all are completed
    });
  }, [activeVideo, activeVideos, subjects, updateProgress, userProgress.videos]);

  const handleVideoPlay = useCallback((video: Video) => {
    // In a real app, this would open a video player (e.g., YouTube embed)
    console.log(`Playing video: ${video.title} (ID: ${video.id})`);
    // After playing, simulate completion for this example
    // For a real app, this would be triggered by an actual video end event
    // For now, immediately mark as complete.
    handleVideoCompleted();
  }, [handleVideoCompleted]);


  const handleMarkTough = useCallback(async (videoId: string) => {
    const videoToUpdate = userProgress.videos[videoId];
    if (!videoToUpdate) return;
    const updated = await updateVideo(videoId, { isTough: !videoToUpdate.isTough });
    updateProgress({ videos: { ...userProgress.videos, [videoId]: updated } });
  }, [userProgress.videos, updateProgress]);

  const handleSaveVideo = useCallback(async (videoId: string) => {
    const videoToUpdate = userProgress.videos[videoId];
    if (!videoToUpdate) return;
    const updated = await updateVideo(videoId, { isSaved: !videoToUpdate.isSaved });
    updateProgress({ videos: { ...userProgress.videos, [videoId]: updated } });
  }, [userProgress.videos, updateProgress]);

  const handleShareVideo = useCallback((video: Video) => {
    if (navigator.share) {
      navigator.share({
        title: video.title,
        text: video.description,
        url: `https://www.youtube.com/watch?v=${video.id}`,
      }).catch(console.error);
    } else {
      navigator.clipboard.writeText(`https://www.youtube.com/watch?v=${video.id}`);
      alert('Video linki panoya kopyalandı!');
    }
  }, []);

  const dailyProgress = Math.round((dailyCompletedVideos / dailyGoalVideos) * 100);

  // Render "Sıradaki" (Next Up) preview card if there's a next video
  const nextVideo = activeVideos[activeVideoIndex + 1];

  const currentSubject = activeVideo ? subjects[activeVideo.subjectKey] : undefined;

  // Filter out duty mode as it stops flow
  if (studyMode === StudyModeKey.DUTY_MODE) {
    return (
      <div className="relative flex flex-col h-screen max-w-md mx-auto w-full bg-background-dark shadow-2xl overflow-hidden">
        <header className="absolute top-0 left-0 right-0 z-40 px-5 pt-12 pb-4 flex items-center justify-between bg-gradient-to-b from-background-dark/90 to-transparent">
            <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-primary" style={{ fontSize: '28px' }}>school</span>
                <h1 className="text-xl font-bold tracking-tight">Mobil Üs</h1>
            </div>
            <div className="flex items-center gap-2 bg-white/10 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/5 shadow-lg">
                <span className="material-symbols-outlined text-orange-500" style={{ fontSize: '20px' }}>local_fire_department</span>
                <span className="text-sm font-bold">{userProgress.dailyStreak} Gün</span>
            </div>
        </header>
        <main className="flex-1 relative z-10 w-full h-full overflow-y-auto snap-y snap-mandatory no-scrollbar pb-24 flex items-center justify-center text-center">
          <div className="p-8 bg-surface-dark rounded-xl border border-white/10 max-w-xs mx-auto">
            <span className="material-symbols-outlined text-emerald-300 text-6xl mb-4">shield_lock</span>
            <h2 className="text-xl font-bold text-white mb-2">Nöbet Modu Aktif!</h2>
            <p className="text-gray-400 text-sm">Video akışı durduruldu. Dinlenme günündesin.</p>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="relative flex flex-col h-screen max-w-md mx-auto w-full bg-background-dark shadow-2xl overflow-hidden">
      {/* Background Ambient Glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-[60vh] bg-primary/20 blur-[120px] rounded-full pointer-events-none z-0"></div>

      {/* Header (Glassmorphic) */}
      <header className="absolute top-0 left-0 right-0 z-40 px-5 pt-12 pb-4 flex items-center justify-between bg-gradient-to-b from-background-dark/95 to-transparent">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center border border-primary/20">
            <span className="material-symbols-outlined text-primary text-[20px]">school</span>
          </div>
          <h1 className="text-lg font-bold tracking-tight">Akıllı Akış</h1>
        </div>
        <div className="flex items-center gap-2 bg-white/5 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/5 shadow-lg">
          <span className="material-symbols-outlined text-orange-500 text-[18px]">local_fire_department</span>
          <span className="text-xs font-bold">{userProgress.dailyStreak} Gün</span>
        </div>
      </header>

      {/* Main Feed Container */}
      <main className="flex-1 relative z-10 w-full h-full overflow-y-auto no-scrollbar pb-28 pt-24">
        {/* Daily Goal Progress (Inline) */}
        <div className="px-5 mb-8">
          <div className="glass-card p-4 rounded-2xl relative overflow-hidden group">
            <div className="absolute right-0 top-0 w-32 h-32 bg-primary/10 blur-[40px] rounded-full -translate-y-1/2 translate-x-1/2"></div>
            <div className="flex justify-between items-end mb-3 relative z-10">
              <div>
                <p className="text-text-secondary text-xs font-bold uppercase tracking-wider mb-1">
                  Günlük Hedef
                </p>
                <p className="text-white text-lg font-bold">
                  {dailyCompletedVideos}/{dailyGoalVideos} Video Tamamlandı
                </p>
              </div>
              <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center border border-primary/20 text-primary">
                <span className="material-symbols-outlined text-[20px]">emoji_events</span>
              </div>
            </div>
            <ProgressBar
              progress={dailyProgress}
              colorClass="primary"
              heightClass="h-2"
              showGlow={true}
            />
            <p className="text-xs text-text-secondary mt-2 font-medium">
              Harika gidiyorsun! Hedefine ulaşmak için {Math.max(0, dailyGoalVideos - dailyCompletedVideos)} video
              daha.
            </p>
          </div>
        </div>

        <div className="relative px-5">
          <div className="absolute left-[34px] top-0 bottom-0 w-[2px] timeline-line-gradient"></div>

          {activeVideos.map((video, index) => {
            const videoSubject = subjects[video.subjectKey];
            if (!videoSubject) return null; // Should not happen with memoized videos

            if (index < activeVideoIndex) {
              return (
                <TimelineVideoItem
                  key={video.id}
                  video={video}
                  subject={videoSubject}
                  status="completed"
                />
              );
            } else if (index === activeVideoIndex && activeVideo) {
              return (
                <div key={activeVideo.id} className="animate-fade-in-up">
                  <VideoCard
                    video={activeVideo}
                    onPlay={handleVideoPlay}
                    onSave={handleSaveVideo}
                    onMarkTough={handleMarkTough}
                    onShare={handleShareVideo}
                  />
                </div>
              );
            } else if (index === activeVideoIndex + 1 && nextVideo) {
                // This is the "Sıradaki" card, ensure it's distinct visually
                return (
                    <div key={nextVideo.id} className="relative pl-10 mb-6 group">
                        <div className="absolute left-1 top-4 w-5 h-5 rounded-full bg-card-dark border-2 border-white/20 flex items-center justify-center z-10">
                            <div className="w-1.5 h-1.5 rounded-full bg-white/40"></div>
                        </div>
                        <div className="glass-card p-3 rounded-xl flex items-center gap-3 transition-colors hover:bg-white/5 cursor-pointer"
                             onClick={() => handleVideoPlay(nextVideo)}> {/* Make it playable from here */}
                            <div className="w-20 h-14 rounded-lg bg-cover bg-center shrink-0 relative overflow-hidden" style={{ backgroundImage: `url('${nextVideo.thumbnailUrl}')` }}>
                                <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                                    <span className="material-symbols-outlined text-white/80 text-[20px]">lock</span>
                                </div>
                            </div>
                            <div className="flex-1 min-w-0">
                                <div className="flex items-center justify-between mb-0.5">
                                    <span className="text-[10px] font-bold text-primary uppercase">Sıradaki</span>
                                    <span className="text-[10px] text-text-secondary flex items-center gap-0.5">
                                        <span className="material-symbols-outlined text-[10px]">schedule</span> {nextVideo.durationInMinutes} dk
                                    </span>
                                </div>
                                <h3 className="text-sm font-semibold text-white truncate">{nextVideo.title}</h3>
                                <p className="text-[11px] text-text-secondary truncate mt-0.5">{nextVideo.description}</p>
                            </div>
                        </div>
                    </div>
                );
            } else if (index > activeVideoIndex + 1) {
              return (
                <TimelineVideoItem
                  key={video.id}
                  video={video}
                  subject={videoSubject}
                  status="upcoming"
                />
              );
            }
            return null;
          })}
        </div>
        <div className="h-10 w-full"></div>
      </main>
    </div>
  );
};

export default SmartFeedScreen;