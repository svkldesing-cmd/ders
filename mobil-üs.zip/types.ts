export enum SubjectKey {
  MATH = 'math',
  HISTORY = 'history',
  GEOGRAPHY = 'geography',
  TURKISH = 'turkish',
  CITIZENSHIP = 'citizenship',
}

export interface Subject {
  key: SubjectKey;
  name: string;
  icon: string; // Material Symbols Outlined icon name
  emoji: string; // Emoji for display
  colorClass: string; // Tailwind color class for styling
  playlistLink: string;
  totalVideos: number;
  completedVideos: number;
  currentVideoIndex: number;
  lastWatchedVideoId?: string;
  progressPercentage: number;
  currentTopic: string;
}

export enum VideoType {
  LECTURE = 'Konu Anlatımı',
  QUESTION_SOLVING = 'Soru Çözümü',
  PRACTICE = 'Deneme',
}

export interface Video {
  id: string; // YouTube video ID
  title: string;
  description: string;
  thumbnailUrl: string;
  durationInMinutes: number;
  subjectKey: SubjectKey;
  type: VideoType;
  isCompleted: boolean;
  isTough: boolean; // Corresponds to "Zor"
  isSaved: boolean; // Corresponds to "Kaydet"
  watchedAt?: number; // Timestamp
  order: number; // Order in the playlist
}

export enum StudyModeKey {
  GOLDEN_DAY = 'golden_day',
  TIRED_MODE = 'tired_mode',
  DUTY_MODE = 'duty_mode',
}

export interface StudyMode {
  key: StudyModeKey;
  name: string;
  description: string;
  icon: string; // Material Symbols Outlined icon name or emoji
  colorClass: string; // Tailwind color class for card styling
  activeSubjects: SubjectKey[] | 'all' | 'none';
}

export enum ActivityType {
  QUESTION = 'QUESTION',
  READING = 'READING',
  VIDEO = 'VIDEO',
  COURSE_COMPLETION = 'COURSE_COMPLETION',
  TEST = 'TEST',
}

export interface Activity {
  id: string;
  type: ActivityType;
  subjectKey?: SubjectKey; // Optional, e.g., for general reading
  description: string;
  value: number; // e.g., number of questions, pages, minutes
  timestamp: number;
}

export enum BookCategory {
  KPSS = 'KPSS',
  TYT = 'TYT',
  AYT = 'AYT',
  GENERAL = 'GENEL',
}

export interface Book {
  id: string;
  title: string;
  category: BookCategory;
  currentPage: number;
  totalPages: number;
  coverGradient: string; // Tailwind gradient class
  progressPercentage: number;
}

export interface UserProgress {
  subjects: { [key in SubjectKey]?: Subject };
  videos: { [videoId: string]: Video }; // Store all videos flat, reference by ID
  studyMode: StudyModeKey;
  activities: Activity[];
  books: Book[];
  dailyStreak: number;
  dailyGoalVideos: number;
  dailyCompletedVideos: number;
  lastLoginDate: string; // YYYY-MM-DD
}

export type ScreenType =
  | 'onboarding'
  | 'study_modes'
  | 'smart_feed'
  | 'courses'
  | 'library'
  | 'statistics';
