import React from 'react';
import { Book } from '../types';
import ProgressBar from './ProgressBar';

interface BookCardProps {
  book: Book;
  onClick?: (bookId: string) => void;
}

const BookCard: React.FC<BookCardProps> = ({ book, onClick }) => {
  return (
    <div className="min-w-[150px] w-[150px] snap-start flex flex-col gap-3 group cursor-pointer" onClick={() => onClick?.(book.id)}>
      <div
        className={`aspect-[2/3] w-full rounded-xl bg-gradient-to-br ${book.coverGradient} relative overflow-hidden shadow-md group-hover:shadow-indigo-500/25 transition-all duration-300 transform group-hover:-translate-y-1`}
      >
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-20 mix-blend-overlay"></div>
        <div className="absolute inset-0 flex flex-col justify-between p-3.5 bg-gradient-to-t from-black/80 via-black/20 to-transparent">
          <div className="self-end px-2 py-0.5 rounded text-[10px] font-bold bg-white/20 backdrop-blur-sm text-white border border-white/10">
            {book.category}
          </div>
          <span className="text-white font-bold text-base leading-tight drop-shadow-sm">{book.title}</span>
        </div>
      </div>
      <div className="flex flex-col gap-1.5 px-0.5">
        <div className="flex justify-between items-end text-xs font-medium text-gray-500 dark:text-gray-400">
          <span className="text-primary font-bold">%{book.progressPercentage}</span>
          <span>
            {book.currentPage}/{book.totalPages}
          </span>
        </div>
        <ProgressBar progress={book.progressPercentage} colorClass="primary" heightClass="h-2" showGlow={true} />
      </div>
    </div>
  );
};

export default BookCard;