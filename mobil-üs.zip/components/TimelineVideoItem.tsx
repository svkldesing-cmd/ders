import React from 'react';
import { Video, Subject } from '../types';

interface TimelineVideoItemProps {
  video: Video;
  subject: Subject; // Pass subject for color context
  status: 'completed' | 'playing' | 'upcoming';
  onPlay?: (video: Video) => void;
}

const TimelineVideoItem: React.FC<TimelineVideoItemProps> = ({ video, subject, status, onPlay }) => {
  const isCompleted = status === 'completed';
  const isPlaying = status === 'playing';
  const isUpcoming = status === 'upcoming';

  const subjectColorClass = subject.colorClass; // e.g., 'green-500'

  return (
    <div className={`relative pl-10 mb-8 ${isCompleted ? 'opacity-60 hover:opacity-100 transition-opacity' : ''} ${isUpcoming ? 'opacity-60' : ''}`}>
      {/* Timeline Marker */}
      <div
        className={`absolute left-0 top-1 w-7 h-7 rounded-full flex items-center justify-center z-10 ${
          isCompleted
            ? 'bg-background-dark border-2 border-green-500 shadow-[0_0_10px_rgba(34,197,94,0.3)]'
            : isPlaying
            ? 'bg-primary border-2 border-primary shadow-[0_0_15px_rgba(19,127,236,0.6)] ring-4 ring-background-dark animate-pulse-slow'
            : 'bg-card-dark border-2 border-white/20'
        }`}
      >
        {isCompleted && <span className="material-symbols-outlined text-green-500 text-[16px]">check</span>}
        {isPlaying && <span className="material-symbols-outlined text-white text-[18px]">play_arrow</span>}
        {isUpcoming && <div className="w-1.5 h-1.5 rounded-full bg-white/40"></div>}
      </div>

      {/* Video Card Content */}
      <div
        className={`glass-card p-3 rounded-xl flex items-center gap-3 transition-colors ${
          isCompleted ? 'border-l-4 border-l-green-500/50' : 'border border-white/5'
        } ${isUpcoming ? '' : 'hover:bg-white/5 cursor-pointer'}`}
        onClick={isUpcoming ? () => onPlay?.(video) : undefined}
      >
        <div
          className={`w-20 h-14 rounded-lg bg-cover bg-center shrink-0 relative overflow-hidden ${isCompleted ? 'grayscale' : ''}`}
          style={{ backgroundImage: `url('${video.thumbnailUrl}')` }}
        >
          {(isUpcoming || !isPlaying) && (
            <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
              {isUpcoming && <span className="material-symbols-outlined text-white/80 text-[20px]">lock</span>}
            </div>
          )}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between mb-0.5">
            <span
              className={`text-[10px] font-bold uppercase ${
                isPlaying
                  ? 'bg-primary text-white shadow-lg shadow-primary/20 px-2 py-0.5 rounded tracking-wide'
                  : isCompleted
                  ? 'text-green-400 bg-green-500/10 px-1.5 py-0.5 rounded'
                  : 'text-text-secondary'
              }`}
            >
              {isPlaying ? 'Şimdi Oynatılıyor' : isCompleted ? 'TAMAMLANDI' : 'Bekliyor'}
            </span>
            <span className="text-[10px] text-text-secondary flex items-center gap-0.5">
              <span className="material-symbols-outlined text-[10px]">schedule</span>{' '}
              {video.durationInMinutes} dk
            </span>
          </div>
          <h3 className={`text-sm font-semibold text-white truncate ${isCompleted ? 'line-through decoration-white/30' : ''}`}>
            {video.title}
          </h3>
          <p className="text-[11px] text-text-secondary truncate mt-0.5">{video.description}</p>
        </div>
      </div>
    </div>
  );
};

export default TimelineVideoItem;