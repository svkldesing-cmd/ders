import React from 'react';
import { Activity, ActivityType } from '../types';

interface ActivityLogItemProps {
  activity: Activity;
}

const getActivityIconAndColor = (type: ActivityType) => {
  switch (type) {
    case ActivityType.QUESTION:
      return { icon: 'edit', color: 'blue-500' };
    case ActivityType.READING:
      return { icon: 'menu_book', color: 'orange-500' };
    case ActivityType.VIDEO:
      return { icon: 'play_circle', color: 'emerald-500' };
    case ActivityType.COURSE_COMPLETION:
      return { icon: 'check_circle', color: 'purple-500' };
    case ActivityType.TEST:
        return { icon: 'assignment', color: 'red-500' };
    default:
      return { icon: 'add_task', color: 'gray-500' };
  }
};

const ActivityLogItem: React.FC<ActivityLogItemProps> = ({ activity }) => {
  const { icon, color } = getActivityIconAndColor(activity.type);
  const time = new Date(activity.timestamp).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });

  return (
    <div className="flex items-center p-3.5 bg-surface-light dark:bg-surface-dark rounded-xl border border-gray-100 dark:border-gray-800 hover:border-primary/30 dark:hover:border-primary/30 transition-colors cursor-pointer group">
      <div className={`w-12 h-12 rounded-xl bg-${color}/10 flex items-center justify-center text-${color} shrink-0 group-hover:bg-${color} group-hover:text-white transition-colors`}>
        <span className="material-symbols-outlined">{icon}</span>
      </div>
      <div className="ml-4 flex-1 min-w-0">
        <div className="flex justify-between items-start">
          <h4 className="text-sm font-bold truncate pr-2 text-slate-800 dark:text-white">
            {activity.subjectKey ? activity.subjectKey.charAt(0).toUpperCase() + activity.subjectKey.slice(1) : ''}
            {activity.type === ActivityType.QUESTION ? ' Soru Çözümü' : ''}
            {activity.type === ActivityType.READING ? ' Okuma' : ''}
            {activity.type === ActivityType.VIDEO ? ' Video İzleme' : ''}
            {activity.type === ActivityType.COURSE_COMPLETION ? ' Ünite Tamamlandı' : ''}
            {activity.type === ActivityType.TEST ? ' Deneme Çözümü' : ''}
          </h4>
          <span className="text-[10px] font-semibold text-gray-400 mt-0.5">{time}</span>
        </div>
        <p className="text-xs font-medium text-gray-500 dark:text-gray-400 mt-0.5">
          {activity.description} {activity.value > 0 && `(${activity.value} ${activity.type === ActivityType.QUESTION ? 'Soru' : activity.type === ActivityType.READING ? 'Sayfa' : 'Dk'})`}
        </p>
      </div>
    </div>
  );
};

export default ActivityLogItem;