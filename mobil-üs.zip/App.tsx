import React, { useState, useEffect, useCallback } from 'react';
import { loadUserProgress, saveUserProgress, updateDailyStreak, resetDailyProgress } from './services/dataService';
import { UserProgress, ScreenType, SubjectKey, StudyModeKey, Subject } from './types';
import { INITIAL_SUBJECTS, STUDY_MODES, MOCK_YOUTUBE_VIDEOS, MOCK_BOOKS } from './constants';

// Screens
import OnboardingScreen from './screens/OnboardingScreen';
import StudyModesScreen from './screens/StudyModesScreen';
import SmartFeedScreen from './screens/SmartFeedScreen';
import CoursesScreen from './screens/CoursesScreen';
import LibraryScreen from './screens/LibraryScreen';
import StatisticsScreen from './screens/StatisticsScreen';
import BottomNavBar from './components/BottomNavBar';


const App: React.FC = () => {
  const [userProgress, setUserProgress] = useState<UserProgress | null>(null);
  const [currentScreen, setCurrentScreen] = useState<ScreenType>('onboarding');
  const [loading, setLoading] = useState<boolean>(true);

  // Load initial data and update streak on app start
  useEffect(() => {
    const initializeApp = async () => {
      let progress = loadUserProgress();

      // Check if onboarding is complete
      const isOnboardingComplete = Object.values(progress.subjects).some(
        (s) => s?.playlistLink !== ''
      );

      if (!isOnboardingComplete && !progress.subjects[SubjectKey.MATH]?.playlistLink) {
        // If no playlist links are set for math, direct to onboarding
        setCurrentScreen('onboarding');
      } else if (!progress.studyMode) {
        // If onboarding is done but study mode is not set, go to study modes
        setCurrentScreen('study_modes');
      } else {
        // Otherwise, go to smart feed
        setCurrentScreen('smart_feed');
      }
      
      // Update daily streak and reset daily progress if it's a new day
      await updateDailyStreak();
      await resetDailyProgress(); // Resets dailyCompletedVideos if it's a new day
      progress = loadUserProgress(); // Reload after updates
      setUserProgress(progress);
      setLoading(false);
    };

    initializeApp();
  }, []); // eslint-disable-next-line react-hooks/exhaustive-deps

  // Effect to save progress whenever it changes
  useEffect(() => {
    if (userProgress && !loading) {
      saveUserProgress(userProgress);
    }
  }, [userProgress, loading]);

  const updateProgress = useCallback((updates: Partial<UserProgress>) => {
    setUserProgress((prev) => {
      if (!prev) return prev;
      const newProgress = { ...prev, ...updates };

      // Recalculate global progress or other derived states if necessary
      if (updates.subjects) {
        const allSubjects = Object.values(newProgress.subjects) as Subject[];
        const totalVideos = allSubjects.reduce((sum, s) => sum + s.totalVideos, 0);
        const completedVideos = allSubjects.reduce((sum, s) => sum + s.completedVideos, 0);
        const overallProgress = totalVideos > 0 ? Math.round((completedVideos / totalVideos) * 100) : 0;

        // Example: Update `progress.overallProgress` if you had one
        // newProgress.overallProgress = overallProgress;
      }

      return newProgress;
    });
  }, []);

  const handleOnboardingComplete = useCallback((updatedSubjects: { [key in SubjectKey]: Subject }) => {
    updateProgress({ subjects: updatedSubjects });
    setCurrentScreen('study_modes');
  }, [updateProgress]);

  const handleStudyModeSelected = useCallback((mode: StudyModeKey) => {
    updateProgress({ studyMode: mode });
    setCurrentScreen('smart_feed');
  }, [updateProgress]);

  const handleNavigate = useCallback((screen: ScreenType) => {
    setCurrentScreen(screen);
  }, []);

  if (loading || !userProgress) {
    // A simple loading screen or splash screen
    return (
      <div className="flex items-center justify-center h-screen bg-background-dark text-white text-xl">
        Yükleniyor...
      </div>
    );
  }

  return (
    <div className="relative flex flex-col h-screen max-w-md mx-auto w-full bg-background-dark shadow-2xl overflow-hidden">
      {/* Background Ambient Glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-[50vh] bg-primary/20 blur-[120px] rounded-full pointer-events-none z-0"></div>

      {currentScreen === 'onboarding' && (
        // Fix: Cast userProgress.subjects to the expected type as loadUserProgress ensures all subjects are present.
        <OnboardingScreen onComplete={handleOnboardingComplete} initialSubjects={userProgress.subjects as {[key in SubjectKey]: Subject}} />
      )}
      {currentScreen === 'study_modes' && (
        <StudyModesScreen onSelectMode={handleStudyModeSelected} currentMode={userProgress.studyMode} />
      )}
      {currentScreen === 'smart_feed' && (
        <SmartFeedScreen userProgress={userProgress} updateProgress={updateProgress} />
      )}
      {currentScreen === 'courses' && (
        <CoursesScreen userProgress={userProgress} updateProgress={updateProgress} />
      )}
      {currentScreen === 'library' && (
        <LibraryScreen userProgress={userProgress} updateProgress={updateProgress} />
      )}
      {currentScreen === 'statistics' && (
        <StatisticsScreen userProgress={userProgress} updateProgress={updateProgress} />
      )}

      {(currentScreen === 'smart_feed' ||
        currentScreen === 'courses' ||
        currentScreen === 'library' ||
        currentScreen === 'statistics') && (
        <BottomNavBar currentScreen={currentScreen} onNavigate={handleNavigate} />
      )}
    </div>
  );
};

export default App;